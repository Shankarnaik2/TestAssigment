package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Customer;
import com.example.demo.repo.CustomerRepo;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepo customerRepo;
	
	@Override
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
 	}
	@Override
	public void saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		this.customerRepo.save(customer);
		
	}
	@Override
	public Customer getCustomerById(long phone) {
		//TODO Auto-generated method stub
		Optional<Customer> optional = customerRepo.findById(phone);
		Customer customer= null;
		if(optional.isPresent()) {
			customer=optional.get();
		}else {
			throw new RuntimeException("Customer not found::"+phone);
		}
		return customer;
	}
//	@Override
	public void deleteBookById(long phone) {
		// TODO Auto-generated method stub
		this.customer.deleteById(phone);
		
	}
  
}
