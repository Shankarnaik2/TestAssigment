package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.models.Customer;
import com.example.demo.service.CustomerService;



@Controller
public class CustomerController {
	
	@Autowired
	private CustomerService CustomerService;
	
	@GetMapping("/")
	public String ViewHomePage(Model model) {
		model.addAttribute("listCustomer",Customer.getAllBooks());
		return "index";
	}
	
	@GetMapping("/showNewCustomerForm")
	public String showNewCustomerForm(Model model) {
		Customer book = new Customer();
		model.addAttribute("Customer", Customer);
		return "new_Customer";
	}
	
	@PostMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("Customer") Customer Customer) {
		CustomerService.saveCustomer(Customer);
		return "redirect:/";
	}
	@GetMapping("/showFormForUpdate/{Id}")
	public String showFormForUpdate(@PathVariable( value = "phone") long phone, Model model) {
		Customer customer=CustomerService.getBookById(Id);
		model.addAttribute("customer", customer);
		return "update_Customer";
	}
	@GetMapping("/deleteCustomer/{phone}")
	public String deleteCustomer(@PathVariable( value = "phone")long phone) {
		this.CustomerService.deleteBookById(phone);
		return "redirect:/";

	}
	 

}
